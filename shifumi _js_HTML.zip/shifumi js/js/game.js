//constante
const send = document.querySelector(".main");
const stringEtat = ['losse','equality','win'];
const game = document.body.innerHTML;

class Gameur {
    constructor(nom,music,photo) {
        this.nom = nom;
        this.music = music;
        this.photo = photo;
    }
}

var Gameurs = [
    new Gameur("mario","mario.mp3"),
    new Gameur("mortal","mortal.mp3"), 
    new Gameur("fireForce","Fire_Force.mp3")
];

//variable
var scroreStar = [0,0,0];
var count = 0;
var scroreFinal = 0;
var pageEnd = "";
var result = "";

function chooseRoboto() {
    var roboto = randomInt(3);
    document.getElementById("sound").src = "assets/sound/" + Gameurs[roboto].music;
    document.getElementById("sound").play();
    document.getElementById("name-comp").innerText = Gameurs[roboto].nom;
    document.getElementById("name-you").innerText =  readCookie('you');
}

function addAndRemoveClass () {
    document.querySelector(".but").classList.toggle("tap");
}

function randomInt(int) {
    return Math.random().toFixed(1) * 10 % int;
}

function sound(id) {
    var sound = document.getElementById(id);
    sound.play();
}

function playGame (youSwicht) {
    
    var computerRamdom = randomInt(2);
    addAndRemoveClass();
    document.getElementById ("you").style.backgroundImage = "url('assets/images/game" + youSwicht + ".png')";
    document.getElementById ("computer").style.backgroundImage = "url('assets/images/game" + computerRamdom + ".png')";
    if(computerRamdom == youSwicht){
        scroreStar[count] = 1;
    }
    else if(computerRamdom == (youSwicht +1)%3){
        scroreStar[count] = 2;
        document.getElementById('star' + count).style.backgroundSize = '';

    }
    else
    {
        scroreStar[count] = 0;

    }
    document.getElementById('star' + count).style.backgroundImage = "url('assets/images/star_" + stringEtat[scroreStar[count]] + ".png')";
    scroreFinal += scroreStar[count];
    count++;

    if(count == 3){
        if(scroreFinal<3){
            result = "loose";
        }
        else if(scroreFinal == 3){
            result = "equality";
        }
        else{
            result = "win";
        }
        setTimeout(endGame,1500);

    }
}

function endGame() {
    pageEnd = "<div id='divend'><p id='end'>" + result + "</p> <div class='score endscrore'><ul><li id='star0'></li><li id='star1'></li><li id='star2'></li></ul></div><a href='index.html' class='end'>Restart</a><buttom href='game.html' class='end' onclick='gamePlay();'>New Part</buttom>";
    document.body.innerHTML = pageEnd;
    var rapport = parseInt(scroreFinal/2);
    var i;
    for(i=0;i<rapport;i++){
        document.getElementById('star'+i).style.backgroundImage = "url('assets/images/star_win.png')";
    }
    scroreFinal = 0;
    centerBody();
}

function gamePlay() {
    count = 0;
    document.body.innerHTML = game;
    chooseRoboto();
}

function centerBody () {
    document.body.style.display = "flex";
    document.body.style.alignItems = "center";
    document.body.style.justifyContent = "center";
    document.body.style.height = "100vh";
}

function readCookie(name) {
    var i, c, ca, nameEQ = name + "=";
    ca = document.cookie.split(';');
    for(i=0;i < ca.length;i++) {
        c = ca[i];
        while (c.charAt(0)==' ') {
            c = c.substring(1,c.length);
        }
        if (c.indexOf(nameEQ) == 0) {
            return c.substring(nameEQ.length,c.length);
        }
    }
    return 'Gameur';
}