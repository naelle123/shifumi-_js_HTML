document.getElementById('submit').addEventListener(
    'click',
    () => {
        var nom = document.getElementById('name').value;
        writeCookie('you', nom, 10);
    }
);


// Fonction pour lire un cookie


function writeCookie(name,value,days) {
    var date, expires;
    if (days) {
        date = new Date();
        date.setTime(date.getTime()+(days*365*60*60*1000));
        expires = "; expires="+date.toGMTString();
    } else {
        expires = "";
    }
    document.cookie = name+"="+value+expires+"; path=/";
}